#ifndef AUDIO_H
#define AUDIO_H
#define AUDIO_RATE 48000
enum { TRK_TITLE, TRK_MAP, TRK_RUN0, TRK_RUN1, TRK_RUN2, TRK_BOSS, TRK_WIN, TRK_LOSE, TRK_COUNT };
enum { SFX_SHOOT, SFX_JUMP, SFX_DASH, SFX_COIN, SFX_HURT, SFX_BOOM, SFX_BIGBOOM, SFX_TICK, SFX_MENU, SFX_SELECT };

void audio_init(void);
void audio_play(int track, int transpose);   /* so reinicia se a faixa mudar */
void audio_set_music(int on);
void audio_sfx(int id);
void audio_mix(float *stereo, int frames);    /* chamado pela thread/callback de audio */
#endif
