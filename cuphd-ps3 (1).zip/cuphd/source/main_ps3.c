/* Camada de plataforma PS3 (PSL1GHT): video por framebuffer RSX, controles e loop. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <unistd.h>
#include <ppu-lv2.h>
#include <sysutil/video.h>
#include <sysutil/sysutil.h>
#include <rsx/gcm_sys.h>
#include <rsx/rsx.h>
#include <io/pad.h>
#include <audio/audio.h>
#include <sys/thread.h>
#include <sys/event_queue.h>
#include "game.h"
#include "audio.h"

#define CB_SIZE   0x100000
#define HOST_SIZE (32 * 1024 * 1024)

typedef struct { int width, height; uint32_t *ptr; uint32_t offset; } Buf;

static gcmContextData *ctx;
static Buf bufs[2];
static int cur_buf = 0, running = 1;
static int scale = 1, offx = 0, offy = 0;

/* ---- audio: thread que enche 1 bloco (256 amostras estereo, float) a cada evento ---- */
static sys_ppu_thread_t snd_tid;
static sys_event_queue_t snd_queue;
static audioPortConfig snd_cfg;
static u32 snd_port;
static volatile int snd_run = 0;

static void audio_thread(void *arg) {
    (void)arg;
    sys_event_t ev;
    while (snd_run) {
        if (sys_event_queue_receive(snd_queue, &ev, 20 * 1000) != 0) continue;
        u64 rd = *(volatile u64 *)(uintptr_t)snd_cfg.readIndex;
        u32 blk = (u32)((rd + 3) % snd_cfg.numBlocks);   /* escreve alguns blocos a frente */
        float *dst = (float *)(uintptr_t)snd_cfg.audioDataStart + blk * 2 * AUDIO_BLOCK_SAMPLES;
        audio_mix(dst, AUDIO_BLOCK_SAMPLES);
    }
    sys_ppu_thread_exit(0);
}
static void init_audio(void) {
    audioPortParam prm; sys_ipc_key_t key;
    if (audioInit() != 0) return;
    prm.numChannels = AUDIO_PORT_2CH; prm.numBlocks = AUDIO_BLOCK_8; prm.attr = 0; prm.level = 1.0f;
    if (audioPortOpen(&prm, &snd_port) != 0) return;
    audioGetPortConfig(snd_port, &snd_cfg);
    audioCreateNotifyEventQueue(&snd_queue, &key);
    audioSetNotifyEventQueue(key);
    audioPortStart(snd_port);
    snd_run = 1;
    sys_ppu_thread_create(&snd_tid, audio_thread, 0, 1500, 0x4000, THREAD_JOINABLE, "cuphd_audio");
}

static void sys_cb(u64 status, u64 param, void *usrdata) {
    (void)param; (void)usrdata;
    if (status == SYSUTIL_EXIT_GAME) running = 0;
}

static void wait_flip(void) {
    while (gcmGetFlipStatus() != 0) usleep(200);
    gcmResetFlipStatus();
}
static void flip(int id) {
    if (gcmSetFlip(ctx, id) == 0) { rsxFlushBuffer(ctx); gcmSetWaitFlip(ctx); }
}
static int make_buffer(Buf *b, int w, int h, int id) {
    int pitch = 4 * w;
    b->ptr = (uint32_t *)rsxMemalign(64, pitch * h);
    if (!b->ptr) return 0;
    if (rsxAddressToOffset(b->ptr, &b->offset) != 0) return 0;
    if (gcmSetDisplayBuffer(id, b->offset, pitch, w, h) != 0) return 0;
    b->width = w; b->height = h;
    return 1;
}
static void init_screen(void) {
    void *host = memalign(1024 * 1024, HOST_SIZE);
    videoState st; videoConfiguration vc; videoResolution res;
    rsxInit(&ctx, CB_SIZE, HOST_SIZE, host);
    videoGetState(0, 0, &st);
    videoGetResolution(st.displayMode.resolution, &res);
    memset(&vc, 0, sizeof vc);
    vc.resolution = st.displayMode.resolution;
    vc.format = VIDEO_BUFFER_FORMAT_XRGB;
    vc.pitch = res.width * 4;
    vc.aspect = st.displayMode.aspect;
    videoConfigure(0, &vc, NULL, 0);
    videoGetState(0, 0, &st);
    gcmSetFlipMode(GCM_FLIP_VSYNC);
    make_buffer(&bufs[0], res.width, res.height, 0);
    make_buffer(&bufs[1], res.width, res.height, 1);
    gcmResetFlipStatus();
    flip(1);
    /* escala inteira 320x176 -> tela (1080p = 6x, 720p = 4x) */
    int sx = res.width / SCR_W, sy = res.height / SCR_H;
    scale = sx < sy ? sx : sy; if (scale < 1) scale = 1;
    offx = (res.width - SCR_W * scale) / 2;
    offy = (res.height - SCR_H * scale) / 2;
}

static void present(void) {
    Buf *b = &bufs[cur_buf];
    static uint32_t row[1920];
    memset(b->ptr, 0, (size_t)b->width * b->height * 4);
    for (int y = 0; y < SCR_H; y++) {
        if (SCR_W * scale > 1920) break;
        for (int x = 0; x < SCR_W; x++) {
            uint32_t c = g_fb[y * SCR_W + x];
            for (int k = 0; k < scale; k++) row[x * scale + k] = c;
        }
        for (int k = 0; k < scale; k++)
            memcpy(b->ptr + (size_t)(offy + y * scale + k) * b->width + offx, row, SCR_W * scale * 4);
    }
    wait_flip();
    flip(cur_buf);
    cur_buf ^= 1;
}

static uint16_t read_pad(int idx, padInfo *info) {
    padData d; uint16_t r = 0;
    if (!info->status[idx]) return 0;
    ioPadGetData(idx, &d);
    if (d.BTN_LEFT  || d.ANA_L_H < 64)  r |= PAD_LEFT;
    if (d.BTN_RIGHT || d.ANA_L_H > 192) r |= PAD_RIGHT;
    if (d.BTN_UP    || d.ANA_L_V < 64)  r |= PAD_UP;
    if (d.BTN_DOWN  || d.ANA_L_V > 192) r |= PAD_DOWN;
    if (d.BTN_CROSS)    r |= PAD_JUMP;
    if (d.BTN_SQUARE)   r |= PAD_SHOOT;
    if (d.BTN_R1 || d.BTN_CIRCLE) r |= PAD_DASH;
    if (d.BTN_START)    r |= PAD_START;
    if (d.BTN_TRIANGLE) r |= PAD_BACK;
    return r;
}

int main(void) {
    padInfo info;
    init_screen();
    ioPadInit(7);
    sysUtilRegisterCallback(0, sys_cb, NULL);
    game_init();
    init_audio();
    while (running && !game_quit_requested()) {
        sysUtilCheckCallback();
        ioPadGetInfo(&info);
        game_update(read_pad(0, &info), read_pad(1, &info));
        present();
    }
    snd_run = 0;
    gcmSetWaitFlip(ctx);
    return 0;
}
