#include "save.h"
#include <stdio.h>
#include <string.h>
#define MAGIC 0x44485043u /* 'CPHD' */
static uint32_t sum(const Save *s) {
    const uint8_t *p = (const uint8_t *)s; uint32_t h = 2166136261u;
    for (unsigned i = 0; i < sizeof(Save) - 4; i++) { h ^= p[i]; h *= 16777619u; }
    return h;
}
void save_defaults(Save *s) { memset(s, 0, sizeof *s); s->magic = MAGIC; s->version = 1; s->music = 1; }
int save_load(Save *s) {
    Save t; FILE *f = fopen(SAVE_PATH, "rb");
    save_defaults(s);
    if (!f) return 0;
    size_t n = fread(&t, 1, sizeof t, f); fclose(f);
    if (n != sizeof t || t.magic != MAGIC || t.version != 1 || t.checksum != sum(&t)) return 0;
    if (t.progress < 0 || t.progress > 5) return 0;
    *s = t; return 1;
}
int save_write(const Save *s) {
    Save t = *s; t.magic = MAGIC; t.version = 1; t.checksum = sum(&t);
    FILE *f = fopen(SAVE_PATH, "wb"); if (!f) return 0;
    size_t n = fwrite(&t, 1, sizeof t, f); fclose(f);
    return n == sizeof t;
}
