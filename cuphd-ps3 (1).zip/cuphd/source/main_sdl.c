/* Versao de PC (SDL2) para testar rapidamente: make -f Makefile.pc
   P1: setas, Z=pular, X=atirar, C=dash, Enter=start, Backspace=voltar
   P2: WASD, G=pular, H=atirar, J=dash */
#include <SDL2/SDL.h>
#include "game.h"
#include "audio.h"
static void snd_cb(void *u, Uint8 *stream, int len) { (void)u; audio_mix((float *)stream, len / 8); }
int main(void) {
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
    SDL_Window *w = SDL_CreateWindow("LUMI E PIP", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCR_W * 4, SCR_H * 4, 0);
    SDL_Renderer *r = SDL_CreateRenderer(w, -1, SDL_RENDERER_PRESENTVSYNC);
    SDL_RenderSetLogicalSize(r, SCR_W, SCR_H);
    SDL_Texture *t = SDL_CreateTexture(r, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, SCR_W, SCR_H);
    game_init();
    SDL_AudioSpec want = {0}; want.freq = AUDIO_RATE; want.format = AUDIO_F32SYS; want.channels = 2; want.samples = 1024; want.callback = snd_cb;
    SDL_AudioDeviceID ad = SDL_OpenAudioDevice(0, 0, &want, 0, 0); if (ad) SDL_PauseAudioDevice(ad, 0);
    for (int run = 1; run && !game_quit_requested();) {
        SDL_Event e; while (SDL_PollEvent(&e)) if (e.type == SDL_QUIT) run = 0;
        const Uint8 *k = SDL_GetKeyboardState(0); uint16_t a = 0, b = 0;
        if (k[SDL_SCANCODE_LEFT]) a |= PAD_LEFT; if (k[SDL_SCANCODE_RIGHT]) a |= PAD_RIGHT;
        if (k[SDL_SCANCODE_UP]) a |= PAD_UP; if (k[SDL_SCANCODE_DOWN]) a |= PAD_DOWN;
        if (k[SDL_SCANCODE_Z]) a |= PAD_JUMP; if (k[SDL_SCANCODE_X]) a |= PAD_SHOOT; if (k[SDL_SCANCODE_C]) a |= PAD_DASH;
        if (k[SDL_SCANCODE_RETURN]) a |= PAD_START; if (k[SDL_SCANCODE_BACKSPACE]) a |= PAD_BACK;
        if (k[SDL_SCANCODE_A]) b |= PAD_LEFT; if (k[SDL_SCANCODE_D]) b |= PAD_RIGHT;
        if (k[SDL_SCANCODE_W]) b |= PAD_UP; if (k[SDL_SCANCODE_S]) b |= PAD_DOWN;
        if (k[SDL_SCANCODE_G]) b |= PAD_JUMP; if (k[SDL_SCANCODE_H]) b |= PAD_SHOOT; if (k[SDL_SCANCODE_J]) b |= PAD_DASH;
        game_update(a, b);
        SDL_UpdateTexture(t, 0, g_fb, SCR_W * 4); SDL_RenderClear(r); SDL_RenderCopy(r, t, 0, 0); SDL_RenderPresent(r);
    }
    return 0;
}
