#ifndef SAVE_H
#define SAVE_H
#include <stdint.h>
#ifndef SAVE_PATH
#define SAVE_PATH "cuphd.sav"
#endif
typedef struct {
    uint32_t magic, version;
    int32_t progress;          /* maior fase liberada no mapa (0..5) */
    int32_t music;             /* 1 = musica ligada */
    int32_t total_coins;
    int32_t best_coins[6];
    int32_t best_time[6];      /* segundos; 0 = nunca concluida */
    uint32_t checksum;
} Save;
void save_defaults(Save *s);
int  save_load(Save *s);       /* 1 se leu um save valido; senao usa padrao */
int  save_write(const Save *s);
#endif
