/* LUMI E PIP - aventura pixel art run'n'gun + chefes (jogo original) */
#include "game.h"
#include "audio.h"
#include "save.h"
#include <math.h>
#include <string.h>
#include <stdlib.h>

#define TS 16
#define MAP_H 11
#define MAP_MAXW 160
#define GROUND_ROW 9
#define PW 10
#define PH 14
#define RND(x) ((int)floorf((x) + 0.5f))
#define PI_F 3.14159265f

uint32_t g_fb[SCR_W * SCR_H];

/* ------------------------------------------------------------ util */
static uint32_t rng_state = 1;
static uint32_t rnd(void) { rng_state = rng_state * 1664525u + 1013904223u; return rng_state >> 8; }
static float rndf(void) { return (rnd() & 0xFFFF) / 65535.0f; }
static int rndi(int a, int b) { return a + (int)(rnd() % (uint32_t)(b - a + 1)); }
static float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }

static uint32_t lerpc(uint32_t a, uint32_t b, float t) {
    int r = (int)(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
    int g = (int)(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
    int bl = (int)((a & 255) * (1 - t) + (b & 255) * t);
    return (uint32_t)((r << 16) | (g << 8) | bl);
}

/* ------------------------------------------------------------ desenho */
static int shx, shy;
static void px(int x, int y, uint32_t c) {
    x += shx; y += shy;
    if ((unsigned)x < SCR_W && (unsigned)y < SCR_H) g_fb[y * SCR_W + x] = c;
}
static void rect(int x, int y, int w, int h, uint32_t c) {
    for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) px(x + i, y + j, c);
}
static void ell(int cx, int cy, int rx, int ry, uint32_t c) {
    for (int j = -ry; j <= ry; j++) {
        float f = 1.0f - (float)(j * j) / (float)(ry * ry + 1);
        int hw = (int)(rx * sqrtf(f < 0 ? 0 : f) + 0.5f);
        for (int i = -hw; i <= hw; i++) px(cx + i, cy + j, c);
    }
}
static void line(int x0, int y0, int x1, int y1, uint32_t c) {
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1, e = dx + dy;
    for (;;) {
        px(x0, y0, c);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * e;
        if (e2 >= dy) { e += dy; x0 += sx; }
        if (e2 <= dx) { e += dx; y0 += sy; }
    }
}
static void tri(int x0, int y0, int x1, int y1, int x2, int y2, uint32_t c) {
    int minx = x0 < x1 ? (x0 < x2 ? x0 : x2) : (x1 < x2 ? x1 : x2);
    int maxx = x0 > x1 ? (x0 > x2 ? x0 : x2) : (x1 > x2 ? x1 : x2);
    int miny = y0 < y1 ? (y0 < y2 ? y0 : y2) : (y1 < y2 ? y1 : y2);
    int maxy = y0 > y1 ? (y0 > y2 ? y0 : y2) : (y1 > y2 ? y1 : y2);
    for (int y = miny; y <= maxy; y++) for (int x = minx; x <= maxx; x++) {
        int d1 = (x - x1) * (y0 - y1) - (x0 - x1) * (y - y1);
        int d2 = (x - x2) * (y1 - y2) - (x1 - x2) * (y - y2);
        int d3 = (x - x0) * (y2 - y0) - (x2 - x0) * (y - y0);
        int neg = (d1 < 0) || (d2 < 0) || (d3 < 0), pos = (d1 > 0) || (d2 > 0) || (d3 > 0);
        if (!(neg && pos)) px(x, y, c);
    }
}

/* fonte 3x5 */
static const char FCH[] = " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,:!?-+/'><";
static const uint8_t FG[][5] = {
    {0,0,0,0,0},{2,5,7,5,5},{6,5,6,5,6},{3,4,4,4,3},{6,5,5,5,6},{7,4,6,4,7},{7,4,6,4,4},{3,4,5,5,3},
    {5,5,7,5,5},{7,2,2,2,7},{1,1,1,5,2},{5,5,6,5,5},{4,4,4,4,7},{5,7,7,5,5},{7,5,5,5,5},{2,5,5,5,2},
    {6,5,6,4,4},{2,5,5,6,3},{6,5,6,5,5},{3,4,2,1,6},{7,2,2,2,2},{5,5,5,5,7},{5,5,5,5,2},{5,5,7,7,5},
    {5,5,2,5,5},{5,5,2,2,2},{7,1,2,4,7},
    {7,5,5,5,7},{2,6,2,2,7},{6,1,2,4,7},{6,1,2,1,6},{5,5,7,1,1},{7,4,6,1,6},{3,4,7,5,7},{7,1,2,2,2},{7,5,7,5,7},{7,5,7,1,6},
    {0,0,0,0,2},{0,0,0,2,4},{0,2,0,2,0},{2,2,2,0,2},{6,1,2,0,2},{0,0,7,0,0},{0,2,7,2,0},{1,1,2,4,4},{2,2,0,0,0},{4,2,1,2,4},{1,2,4,2,1}
};
static int text_w(const char *s, int sc) { return (int)strlen(s) * 4 * sc - sc; }
static void text_raw(int x, int y, const char *s, uint32_t col, int sc) {
    for (; *s; s++, x += 4 * sc) {
        const char *p = strchr(FCH, *s);
        if (!p || !*s) continue;
        int gi = (int)(p - FCH);
        for (int r = 0; r < 5; r++) for (int c = 0; c < 3; c++)
            if ((FG[gi][r] >> (2 - c)) & 1) rect(x + c * sc, y + r * sc, sc, sc, col);
    }
}
static void text(int x, int y, const char *s, uint32_t col, int sc) {
    text_raw(x + sc, y + sc, s, 0x0c0816, sc);
    text_raw(x, y, s, col, sc);
}
static void text_c(int y, const char *s, uint32_t col, int sc) { text((SCR_W - text_w(s, sc)) / 2, y, s, col, sc); }
static void num_str(char *buf, int n) { /* int -> texto */
    char t[12]; int l = 0; if (n <= 0) { strcpy(buf, "0"); return; }
    while (n) { t[l++] = '0' + n % 10; n /= 10; }
    for (int i = 0; i < l; i++) buf[i] = t[l - 1 - i];
    buf[l] = 0;
}

/* ------------------------------------------------------------ sprites */
static const char *SPR_LUMI_A[15] = {
    "....oooo....", "..oohhhhoo..", ".ohhggghhho.", ".ohgggwkhho.", ".ohgggwkhho.",
    "..ohhhhhho..", "...oooooo...", "..obbbbbbo..", ".obbbddbbbo.", ".obbbddbbbo.",
    "..obbbbbbo..", "...obbbbo...", "...od..do...", "...od..do...", "..ooo..ooo.."
};
static const char *SPR_LUMI_B[15] = {
    "....oooo....", "..oohhhhoo..", ".ohhggghhho.", ".ohgggwkhho.", ".ohgggwkhho.",
    "..ohhhhhho..", "...oooooo...", "..obbbbbbo..", ".obbbddbbbo.", ".obbbddbbbo.",
    "..obbbbbbo..", "...obbbbo...", "..od....do..", ".od......do.", "ooo......ooo"
};
typedef struct { uint32_t h, g, b, d; } Pal;
static const Pal PALS[2] = {
    { 0xffd23c, 0xfff4a0, 0x3c78e6, 0x2850b4 },   /* Lumi: lampada amarela, corpo azul */
    { 0xff7aa8, 0xffc8dc, 0xf08c32, 0xb45c1e }    /* Pip: lampada rosa, corpo laranja */
};
static void draw_spr(int x, int y, const char **rows, int w, int h, int flip, const Pal *pl, int white) {
    for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) {
        char ch = rows[j][flip ? w - 1 - i : i];
        uint32_t c;
        switch (ch) {
            case 'o': c = 0x1a1226; break;
            case 'h': c = pl->h; break;
            case 'g': c = pl->g; break;
            case 'b': c = pl->b; break;
            case 'd': c = pl->d; break;
            case 'w': c = 0xffffff; break;
            case 'k': c = 0x1a1226; break;
            default: continue;
        }
        if (white && ch != 'o') c = 0xffffff;
        px(x + i, y + j, c);
    }
}

/* ------------------------------------------------------------ dados do jogo */
enum { K_RUN, K_BOSS, K_TUT };
typedef struct { const char *name, *sub; int kind, world, boss, len, diff; } LevelDef;
static const LevelDef LV[] = {
    { "TUTORIAL", "COMO JOGAR", K_TUT, 0, 0, 82, 0 },
    { "FLORESTA SOMBRIA", "CORRE E ATIRA", K_RUN, 0, 0, 120, 1 },
    { "REI GELATINA", "CHEFE", K_BOSS, 0, 0, 20, 1 },
    { "DUNAS DO CREPUSCULO", "CORRE E ATIRA", K_RUN, 1, 0, 130, 2 },
    { "MESTRE CORVO", "CHEFE", K_BOSS, 1, 1, 20, 2 },
    { "CASTELO ESQUECIDO", "CORRE E ATIRA", K_RUN, 2, 0, 140, 3 },
    { "RAINHA TROVAO", "CHEFE FINAL", K_BOSS, 2, 2, 20, 3 },
};
#define NODES 6

typedef struct { float x, y, vx, vy; int face, hp, alive, ground, inv, dash, dashcd, shootcd, coyote, jbuf, anim, respawn, jumps, drop; float sx, sy; } Player;
typedef struct { float x, y, vx, vy, ay; int life, enemy, on; } Bullet;
typedef struct { int type, on, act, w, h, hp, t, dir, flash; float x, y, vx, vy, by; } Enemy;
typedef struct { float x, y; int got; } Coin;
typedef struct { float x, y, vx, vy; int life, max; uint32_t c; } Part;
typedef struct { int type, on, w, h, hp, maxhp, state, t, t2, cnt, flash, dying; float x, y, vx, vy; } Boss;
typedef struct { int x, t, on; } Beam;

#define MAXB 160
#define MAXE 48
#define MAXC 96
#define MAXP 300

enum { S_TITLE, S_MAP, S_PLAY, S_RESULT };
static Save sv;
static int new_record;
static int state, np = 1, menusel, mapsel, progress, cur, frame, want_quit;
static uint16_t held[2], oldheld[2], prs[2];

static uint8_t tiles[MAP_H][MAP_MAXW];
static int map_w;
static Player pl[2];
static Bullet bl[MAXB];
static Enemy en[MAXE];
static Coin coins[MAXC];
static int ncoins, coins_got, level_time;
static Part part[MAXP];
static Boss boss;
static Beam beams[2];
static float camx;
static int shake, intro, paused, end_timer, res_win, tut;

static struct { int x; const char *s; } TUTP[] = {
    { 0, "MOVA COM D-PAD OU ANALOGICO" },
    { 12, "X PULA - SEGURE PARA PULAR MAIS ALTO" },
    { 24, "X DE NOVO NO AR: PULO DUPLO" },
    { 34, "R1 OU O: DASH - VOCE FICA INVENCIVEL" },
    { 44, "QUADRADO ATIRA - CIMA MIRA PARA CIMA" },
    { 62, "BAIXO + X DESCE DA PLATAFORMA" },
    { 72, "CHEGUE A BANDEIRA PARA VENCER" },
};

/* ------------------------------------------------------------ fisica */
static int tile(int tx, int ty) {
    if (ty < 0 || ty >= MAP_H) return 0;
    if (tx < 0 || tx >= map_w) return 1;
    return tiles[ty][tx];
}
static int hit_solid(float x, float y, int w, int h) {
    int x0 = (int)floorf(x / TS), x1 = (int)floorf((x + w - 0.01f) / TS);
    int y0 = (int)floorf(y / TS), y1 = (int)floorf((y + h - 0.01f) / TS);
    for (int ty = y0; ty <= y1; ty++) for (int tx = x0; tx <= x1; tx++) if (tile(tx, ty) == 1) return 1;
    return 0;
}
static int move_body(float *x, float *y, float *vx, float *vy, int w, int h, int drop) {
    int ground = 0;
    *x += *vx;
    if (hit_solid(*x, *y, w, h)) {
        if (*vx > 0) *x = floorf((*x + w - 0.01f) / TS) * TS - w;
        else if (*vx < 0) *x = (floorf(*x / TS) + 1) * TS;
        *vx = 0;
    }
    float oldb = *y + h;
    *y += *vy;
    if (*vy >= 0) {
        int ty = (int)floorf((*y + h) / TS);
        int x0 = (int)floorf(*x / TS), x1 = (int)floorf((*x + w - 0.01f) / TS);
        for (int tx = x0; tx <= x1; tx++) {
            int t = tile(tx, ty);
            if (t == 1 || (t == 2 && !drop && oldb <= ty * TS + 0.5f)) { *y = ty * TS - h; *vy = 0; ground = 1; break; }
        }
    } else if (hit_solid(*x, *y, w, h)) {
        *y = (floorf(*y / TS) + 1) * TS; *vy = 0;
    }
    return ground;
}

/* ------------------------------------------------------------ efeitos */
static void burst(float x, float y, int n, uint32_t c) {
    for (int k = 0; k < n; k++) for (int i = 0; i < MAXP; i++) if (part[i].life <= 0) {
        float a = rndf() * 2 * PI_F, s = 0.5f + rndf() * 2.0f;
        part[i].x = x; part[i].y = y; part[i].vx = cosf(a) * s; part[i].vy = sinf(a) * s - 0.5f;
        part[i].life = part[i].max = 14 + rndi(0, 16); part[i].c = c; break;
    }
}
static void spawn_b(float x, float y, float vx, float vy, float ay, int enemy, int life) {
    for (int i = 0; i < MAXB; i++) if (!bl[i].on) {
        bl[i].x = x; bl[i].y = y; bl[i].vx = vx; bl[i].vy = vy; bl[i].ay = ay; bl[i].enemy = enemy; bl[i].life = life; bl[i].on = 1; return;
    }
}
static void fire(float x, float y, float ang, float spd) { spawn_b(x, y, cosf(ang) * spd, sinf(ang) * spd, 0, 1, 260); }

static Player *nearest(float x) {
    Player *best = 0; float bd = 1e9f;
    for (int i = 0; i < np; i++) if (pl[i].alive) {
        float d = fabsf(pl[i].x - x);
        if (d < bd) { bd = d; best = &pl[i]; }
    }
    return best ? best : &pl[0];
}
static int overlap(float ax, float ay, int aw, int ah, float bx, float by, int bw, int bh) {
    return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
}
static void hurt(Player *p) {
    if (tut || !p->alive || p->inv > 0 || p->dash > 0) return;
    p->hp--; p->inv = 90; audio_sfx(SFX_HURT); p->vy = -3.0f; p->vx = -p->face * 2.0f; shake = 6;
    burst(p->x + 5, p->y + 7, 10, 0xff5050);
    if (p->hp <= 0) { p->alive = 0; p->respawn = 360; burst(p->x + 5, p->y + 7, 30, 0xffffff); }
}

/* ------------------------------------------------------------ fases */
static void add_enemy(int type, float x, float y) {
    for (int i = 0; i < MAXE; i++) if (!en[i].on) {
        Enemy *e = &en[i]; memset(e, 0, sizeof *e);
        e->on = 1; e->type = type; e->x = x; e->y = y; e->by = y; e->dir = -1;
        e->w = type == 0 ? 12 : (type == 1 ? 12 : 14); e->h = type == 0 ? 10 : (type == 1 ? 10 : 14);
        e->hp = type == 0 ? 3 : (type == 1 ? 2 : 5);
        return;
    }
}
static void add_coin(float x, float y) { if (ncoins < MAXC) { coins[ncoins].x = x; coins[ncoins].y = y; coins[ncoins].got = 0; ncoins++; } }
static void put_ground(int x0, int x1, int on) { for (int x = x0; x < x1 && x < map_w; x++) for (int r = GROUND_ROW; r < MAP_H; r++) tiles[r][x] = on; }
static void put_plat(int x0, int w, int row) { for (int x = x0; x < x0 + w && x < map_w; x++) tiles[row][x] = 2; }
static void put_block(int x0, int w, int h) { for (int x = x0; x < x0 + w; x++) for (int k = 1; k <= h; k++) tiles[GROUND_ROW - k][x] = 1; }
static void coin_arc(int tx, int n, int ty) { for (int i = 0; i < n; i++) add_coin(tx * TS + i * 12 + 4, ty * TS - 10 - sinf(i * PI_F / (n > 1 ? n - 1 : 1)) * 14); }

static void build_level(int id) {
    const LevelDef *L = &LV[id];
    memset(tiles, 0, sizeof tiles); memset(en, 0, sizeof en); memset(coins, 0, sizeof coins); ncoins = 0;
    map_w = L->len; rng_state = 1234 + id * 77;
    put_ground(0, map_w, 1);
    if (L->kind == K_BOSS) { put_plat(2, 4, 6); put_plat(14, 4, 6); put_plat(8, 4, 7 - 0); return; }
    if (L->kind == K_TUT) {
        put_block(18, 2, 1); put_ground(28, 31, 0); put_plat(31, 0, 6);
        put_plat(44, 0, 7); put_plat(64, 6, 7); put_block(70, 2, 1);
        add_enemy(0, 52 * TS, GROUND_ROW * TS - 10); add_enemy(0, 56 * TS, GROUND_ROW * TS - 10);
        add_enemy(1, 59 * TS, 90);
        for (int i = 0; i < 5; i++) add_coin(8 * TS + i * 14, 120);
        coin_arc(27, 5, 8); coin_arc(64, 6, 7); coin_arc(36, 6, 8);
        return;
    }
    int x = 14;
    while (x < map_w - 14) {
        int k = rndi(0, 9);
        if (k <= 2) { int w = rndi(2, 3); put_ground(x, x + w, 0); coin_arc(x - 1, w + 2, GROUND_ROW - 1); x += w + 6; }
        else if (k <= 4) { int w = rndi(2, 3), h = rndi(1, 2); put_block(x, w, h); add_coin(x * TS + 8, (GROUND_ROW - h) * TS - 14); x += w + 5; }
        else if (k <= 7) {
            int w = rndi(3, 5), row = rndi(6, 7); put_plat(x, w, row);
            for (int i = 0; i < w; i++) add_coin((x + i) * TS + 4, row * TS - 12);
            if (L->diff >= 2 && rndi(0, 1)) add_enemy(2, (x + w) * TS + 20, GROUND_ROW * TS - 14);
            x += w + 4;
        } else x += 6;
    }
    put_ground(map_w - 14, map_w, 1);
    for (int ex = 24; ex < map_w - 16; ex += rndi(6, 10)) {
        int t = rndi(0, 9); int type = t < 5 ? 0 : (t < 8 ? 1 : (L->diff >= 2 ? 2 : 0));
        if (tiles[GROUND_ROW][ex] != 1 || tiles[GROUND_ROW - 1][ex] != 0 || tiles[GROUND_ROW][ex + 1] != 1) continue;
        if (type == 1) add_enemy(1, ex * TS, rndi(60, 110));
        else add_enemy(type, ex * TS, GROUND_ROW * TS - (type == 0 ? 10 : 14));
    }
}

static void start_level(int id) {
    const LevelDef *L = &LV[id];
    cur = id; state = S_PLAY; tut = (L->kind == K_TUT);
    build_level(id);
    memset(bl, 0, sizeof bl); memset(part, 0, sizeof part); memset(&boss, 0, sizeof boss); memset(beams, 0, sizeof beams);
    for (int i = 0; i < 2; i++) {
        Player *p = &pl[i]; memset(p, 0, sizeof *p);
        p->x = 28 + i * 16; p->y = GROUND_ROW * TS - PH - 2; p->face = 1; p->hp = 3; p->alive = (i < np);
        p->sx = p->x; p->sy = p->y;
    }
    camx = 0; shake = 0; intro = 150; paused = 0; end_timer = 0; res_win = 0; coins_got = 0; level_time = 0;
    if (L->kind == K_BOSS) {
        boss.on = 1; boss.type = L->boss;
        int base[3] = { 70, 90, 120 };
        boss.maxhp = boss.hp = base[L->boss] * (np == 2 ? 16 : 10) / 10;
        if (L->boss == 0) { boss.w = 56; boss.h = 40; boss.x = 220; boss.y = GROUND_ROW * TS - 40; }
        if (L->boss == 1) { boss.w = 44; boss.h = 28; boss.x = 140; boss.y = 34; }
        if (L->boss == 2) { boss.w = 36; boss.h = 36; boss.x = 142; boss.y = 44; }
        boss.t = -60;
    }
}

/* ------------------------------------------------------------ jogadores */
static void update_player(int i) {
    Player *p = &pl[i]; uint16_t h = held[i], pr = prs[i];
    if (i >= np) return;
    if (!p->alive) {
        if (np == 2 && pl[1 - i].alive && --p->respawn <= 0) {
            p->alive = 1; p->hp = 1; p->x = pl[1 - i].x; p->y = pl[1 - i].y - 20; p->vy = 0; p->inv = 150;
        }
        return;
    }
    int dir = ((h & PAD_RIGHT) ? 1 : 0) - ((h & PAD_LEFT) ? 1 : 0);
    if (p->inv > 0) p->inv--;
    if (p->dashcd > 0) p->dashcd--;
    if (p->shootcd > 0) p->shootcd--;
    if (p->drop > 0) p->drop--;
    if (dir) p->face = dir;
    if ((pr & PAD_DASH) && p->dashcd <= 0 && p->dash <= 0) { p->dash = 13; p->dashcd = 36; audio_sfx(SFX_DASH); }
    if (p->dash > 0) {
        p->dash--; p->vx = p->face * 3.8f; p->vy = 0;
        for (int k = 0; k < 2; k++) burst(p->x + 5, p->y + 7, 1, 0x9fd8ff);
    } else {
        p->vx += (dir * 1.5f - p->vx) * (p->ground ? 0.35f : 0.2f);
        p->vy += 0.22f; if (p->vy > 6.5f) p->vy = 6.5f;
    }
    if (p->ground) { p->coyote = 6; p->jumps = 0; }
    else if (p->coyote > 0 && --p->coyote == 0 && p->jumps == 0) p->jumps = 1;
    if (pr & PAD_JUMP) p->jbuf = 6; else if (p->jbuf > 0) p->jbuf--;
    if (p->jbuf > 0) {
        int onplat = p->ground && tile((int)floorf((p->x + PW / 2) / TS), (int)floorf((p->y + PH + 1) / TS)) == 2;
        if ((h & PAD_DOWN) && onplat) { p->drop = 10; p->jbuf = 0; p->ground = 0; }
        else if (p->coyote > 0) { p->vy = -4.7f; p->jbuf = 0; p->coyote = 0; p->jumps = 1; audio_sfx(SFX_JUMP); burst(p->x + 5, p->y + PH, 4, 0xdddddd); }
        else if (p->jumps < 2) { p->vy = -4.2f; p->jbuf = 0; p->jumps = 2; audio_sfx(SFX_JUMP); burst(p->x + 5, p->y + PH, 8, 0x9fd8ff); }
    }
    if (!(h & PAD_JUMP) && p->vy < -2.0f && p->dash <= 0) p->vy *= 0.85f;
    p->ground = move_body(&p->x, &p->y, &p->vx, &p->vy, PW, PH, p->drop > 0);
    float cmin = camx, cmax = camx + SCR_W - PW;
    if (p->x < cmin) { p->x = cmin; p->vx = 0; }
    if (p->x > cmax) { p->x = cmax; p->vx = 0; }
    if (p->ground) {
        int cx = (int)floorf((p->x + PW / 2) / TS);
        if (tile(cx - 1, GROUND_ROW) == 1 && tile(cx, GROUND_ROW) == 1 && tile(cx + 1, GROUND_ROW) == 1) { p->sx = p->x; p->sy = p->y; }
    }
    if (p->y > SCR_H + 12) {
        p->x = p->sx; p->y = p->sy - 2; p->vx = p->vy = 0;
        if (!tut) { hurt(p); } 
        p->inv = 90;
    }
    p->anim = (p->ground && fabsf(p->vx) > 0.4f) ? p->anim + 1 : 0;
    if ((h & PAD_SHOOT) && p->shootcd <= 0 && p->dash <= 0) {
        int up = (h & PAD_UP) != 0; p->shootcd = 7;
        float bx = p->x + PW / 2 + p->face * 6, by = p->y + 5, vx = p->face * 6.0f, vy = (rndf() - 0.5f) * 0.4f;
        if (up && !dir) { vx = 0; vy = -6.0f; bx = p->x + PW / 2; by = p->y - 2; }
        else if (up) { vx = p->face * 4.25f; vy = -4.25f; }
        spawn_b(bx, by, vx, vy, 0, 0, 45); audio_sfx(SFX_SHOOT);
        burst(bx, by, 1, 0xfff4a0);
    }
    for (int c = 0; c < ncoins; c++) if (!coins[c].got && overlap(p->x, p->y, PW, PH, coins[c].x - 3, coins[c].y - 3, 8, 8)) {
        coins[c].got = 1; coins_got++; audio_sfx(SFX_COIN); burst(coins[c].x, coins[c].y, 6, 0xffe060);
    }
}

/* ------------------------------------------------------------ inimigos */
static void kill_enemy(Enemy *e) {
    audio_sfx(SFX_BOOM);
    burst(e->x + e->w / 2, e->y + e->h / 2, 18, e->type == 0 ? 0xa56bff : (e->type == 1 ? 0xff6b86 : 0x6bffc0));
    if (ncoins < MAXC && rndi(0, 2) == 0) add_coin(e->x + e->w / 2, e->y);
    e->on = 0;
}
static void update_enemies(void) {
    for (int i = 0; i < MAXE; i++) {
        Enemy *e = &en[i]; if (!e->on) continue;
        if (!e->act) { if (e->x < camx + SCR_W + 24) e->act = 1; else continue; }
        if (e->x + e->w < camx - 48) { e->on = 0; continue; }
        e->t++; if (e->flash > 0) e->flash--;
        int diff = LV[cur].diff;
        if (e->type == 0) {
            float ox = e->x; e->vx = e->dir * (0.45f + 0.1f * diff); e->vy += 0.22f;
            move_body(&e->x, &e->y, &e->vx, &e->vy, e->w, e->h, 0);
            int ahead = tile((int)floorf((e->x + (e->dir > 0 ? e->w + 2 : -2)) / TS), (int)floorf((e->y + e->h + 2) / TS));
            if (fabsf(e->x - ox) < 0.01f || ahead == 0) e->dir = -e->dir;
        } else if (e->type == 1) {
            e->x -= 0.8f + 0.1f * diff; e->y = e->by + sinf(e->t * 0.07f) * 18;
        } else {
            if (e->t % (130 - diff * 15) == 0 && e->x < camx + SCR_W - 8) {
                Player *p = nearest(e->x);
                float a = atan2f(p->y + 6 - (e->y + 4), p->x + 5 - (e->x + 7));
                fire(e->x + 7, e->y + 4, a, 1.6f);
            }
        }
        for (int k = 0; k < np; k++) if (pl[k].alive && overlap(pl[k].x, pl[k].y, PW, PH, e->x + 1, e->y + 1, e->w - 2, e->h - 2)) hurt(&pl[k]);
    }
}

/* ------------------------------------------------------------ chefes */
static void update_boss(void) {
    Boss *b = &boss; if (!b->on) return;
    if (b->flash > 0) b->flash--;
    if (b->dying > 0) {
        if (--b->dying % 4 == 0) burst(b->x + rndf() * b->w, b->y + rndf() * b->h, 10, 0xffd060);
        shake = 4;
        if (b->dying == 0) { b->on = 0; end_timer = 100; res_win = 1; }
        return;
    }
    if (b->hp <= 0) {
        b->dying = 100; audio_sfx(SFX_BIGBOOM); for (int i = 0; i < MAXB; i++) if (bl[i].enemy) bl[i].on = 0;
        memset(beams, 0, sizeof beams); return;
    }
    if (b->t < 0) { b->t++; return; }
    int ph2 = b->hp < b->maxhp / 2;
    Player *tp = nearest(b->x + b->w / 2);
    float tx = tp->x + PW / 2, ty = tp->y + PH / 2, cx = b->x + b->w / 2, cy = b->y + b->h / 2;
    b->t++;
    if (b->type == 0) { /* Rei Gelatina */
        float gy = GROUND_ROW * TS - b->h;
        if (b->state == 0) {
            b->y = gy;
            if (b->t > (ph2 ? 25 : 45)) {
                b->t = 0;
                if (b->cnt % 3 == 2) {
                    for (int k = -1; k <= 1; k++) spawn_b(cx, b->y, k * 1.1f + (tx > cx ? 0.8f : -0.8f), -4.2f - rndf(), 0.15f, 1, 200);
                    b->cnt++;
                } else { b->vy = -6.5f; b->vx = clampf((tx - cx) / 52.0f, -3.2f, 3.2f); b->state = 1; }
            }
        } else {
            b->vy += 0.25f; b->x += b->vx; b->y += b->vy;
            if (b->y >= gy && b->vy > 0) {
                b->y = gy; b->state = 0; b->t = 0; b->cnt++; shake = 10;
                float sp = ph2 ? 3.0f : 2.3f;
                spawn_b(cx - 10, GROUND_ROW * TS - 4, -sp, 0, 0, 1, 140);
                spawn_b(cx + 10, GROUND_ROW * TS - 4, sp, 0, 0, 1, 140);
            }
        }
        b->x = clampf(b->x, 4, SCR_W - 4 - b->w);
    } else if (b->type == 1) { /* Mestre Corvo */
        if (b->state == 0) {
            float t0 = SCR_W / 2 + sinf(b->t * (ph2 ? 0.035f : 0.025f)) * 110 - b->w / 2;
            b->x += (t0 - b->x) * 0.05f; b->y += (34 + sinf(b->t * 0.07f) * 8 - b->y) * 0.1f;
            if (b->t % (ph2 ? 55 : 80) == 0) {
                int n = ph2 ? 7 : 5; float base = atan2f(ty - cy, tx - cx);
                for (int k = 0; k < n; k++) fire(cx, cy + 6, base + (k - (n - 1) / 2.0f) * 0.28f, 2.1f);
                if (++b->cnt >= 3) { b->cnt = 0; b->state = 1; b->t = 0; }
            }
        } else if (b->state == 1) {
            b->x += (tx - b->w / 2 - b->x) * 0.08f; b->y += (20 - b->y) * 0.1f;
            if (b->t > 40) b->state = 2;
        } else if (b->state == 2) {
            b->y += 7;
            if (b->y >= GROUND_ROW * TS - b->h) { b->y = GROUND_ROW * TS - b->h; b->state = 3; shake = 8; }
        } else { b->y -= 2.5f; if (b->y <= 34) { b->state = 0; b->t = 0; } }
        b->x = clampf(b->x, 2, SCR_W - 2 - b->w);
    } else { /* Rainha Trovao */
        b->y = 44 + sinf(b->t * 0.03f) * 8; b->x = SCR_W / 2 - b->w / 2 + sinf(b->t * 0.017f) * 40;
        int pat = b->cnt % 3, T = b->t2++;
        if (pat == 0) {
            if (T % (ph2 ? 32 : 45) == 10) { float off = rndf() * 6.28f; for (int k = 0; k < 14; k++) fire(cx, cy, off + k * 2 * PI_F / 14, 1.7f); }
            if (T > 200) { b->cnt++; b->t2 = 0; }
        } else if (pat == 1) {
            if (T % 4 == 0 && T < 130) { fire(cx, cy, T * 0.4f, 1.5f); if (ph2) fire(cx, cy, T * 0.4f + PI_F, 1.5f); }
            if (T > 170) { b->cnt++; b->t2 = 0; }
        } else {
            if (T == 5) { beams[0].x = (int)tx; beams[0].t = 0; beams[0].on = 1; }
            if (ph2 && T == 30) { beams[1].x = rndi(30, SCR_W - 30); beams[1].t = 0; beams[1].on = 1; }
            if (T > 140) { b->cnt++; b->t2 = 0; }
        }
    }
    for (int k = 0; k < np; k++) if (pl[k].alive && overlap(pl[k].x, pl[k].y, PW, PH, b->x + 4, b->y + 4, b->w - 8, b->h - 8)) hurt(&pl[k]);
}
static void update_beams(void) {
    for (int i = 0; i < 2; i++) if (beams[i].on) {
        beams[i].t++;
        if (beams[i].t >= 45 && beams[i].t < 70)
            for (int k = 0; k < np; k++) if (pl[k].alive && overlap(pl[k].x, pl[k].y, PW, PH, beams[i].x - 9, 0, 18, SCR_H)) hurt(&pl[k]);
        if (beams[i].t >= 70) beams[i].on = 0;
    }
}

/* ------------------------------------------------------------ balas */
static void update_bullets(void) {
    int cxi = RND(camx);
    for (int i = 0; i < MAXB; i++) {
        Bullet *b = &bl[i]; if (!b->on) continue;
        b->vy += b->ay; b->x += b->vx; b->y += b->vy;
        if (--b->life <= 0 || b->x < cxi - 20 || b->x > cxi + SCR_W + 20 || b->y < -20 || b->y > SCR_H + 20) { b->on = 0; continue; }
        if (tile((int)floorf(b->x / TS), (int)floorf(b->y / TS)) == 1) { burst(b->x, b->y, 3, b->enemy ? 0xff6080 : 0xfff4a0); b->on = 0; continue; }
        if (!b->enemy) {
            for (int j = 0; j < MAXE; j++) {
                Enemy *e = &en[j];
                if (e->on && e->act && b->x > e->x - 2 && b->x < e->x + e->w + 2 && b->y > e->y - 2 && b->y < e->y + e->h + 2) {
                    b->on = 0; e->flash = 3; burst(b->x, b->y, 3, 0xffffff);
                    if (--e->hp <= 0) kill_enemy(e);
                    break;
                }
            }
            if (b->on && boss.on && boss.dying == 0 && boss.t >= 0 && b->x > boss.x && b->x < boss.x + boss.w && b->y > boss.y && b->y < boss.y + boss.h) {
                b->on = 0; boss.hp--; boss.flash = 3; if (frame % 3 == 0) audio_sfx(SFX_TICK); burst(b->x, b->y, 2, 0xffffff);
            }
        } else {
            for (int k = 0; k < np; k++) if (pl[k].alive && b->x > pl[k].x - 2 && b->x < pl[k].x + PW + 2 && b->y > pl[k].y - 2 && b->y < pl[k].y + PH + 2) {
                if (pl[k].inv <= 0 && pl[k].dash <= 0) { hurt(&pl[k]); b->on = 0; }
                break;
            }
        }
    }
}

/* ------------------------------------------------------------ fundos */
static const uint32_t SKYT[3] = { 0x2a1a4e, 0x3b1d5a, 0x0a0a1c }, SKYB[3] = { 0xe8885a, 0xf4b05e, 0x3a1c4d };
static const uint32_t HILLF[3] = { 0x3a2a5a, 0x7a3a6a, 0x1a1530 }, HILLN[3] = { 0x24443a, 0x9a5a4a, 0x241c3a };
static const uint32_t TTOP[3] = { 0x62c45a, 0xe0b25a, 0x7a6aba }, TBODY[3] = { 0x4a3040, 0x8a5a3a, 0x2c2440 }, TDARK[3] = { 0x3a2434, 0x6a4430, 0x201a32 };

static void draw_bg(int w, float cam) {
    for (int y = 0; y < SCR_H; y++) {
        uint32_t c = lerpc(SKYT[w], SKYB[w], (float)y / SCR_H);
        for (int x = 0; x < SCR_W; x++) g_fb[y * SCR_W + x] = c;
    }
    if (w != 1) for (int i = 0; i < 40; i++) {
        int sx = (i * 73) % SCR_W, sy = (i * 37) % 70;
        if (((frame / 20 + i) % 5) != 0) px(sx, sy, 0xffffff);
    }
    if (w == 2) { ell(250, 38, 16, 16, 0xe8e8ff); ell(256, 34, 14, 14, 0x1a1634 + 0x0a0a1c * 0); ell(250, 38, 16, 16, 0xe8e8ff); ell(257, 34, 13, 13, 0x1c1838); }
    else ell(70, 96, 22, 22, w == 0 ? 0xffb070 : 0xfff0b0);
    int cx = RND(cam);
    for (int x = 0; x < SCR_W; x++) {
        float wx = x + cx * 0.2f;
        int hy = (int)(104 + sinf(wx * 0.02f) * 14 + sinf(wx * 0.05f) * 6);
        for (int y = hy; y < SCR_H; y++) g_fb[y * SCR_W + x] = HILLF[w];
    }
    /* props na camada media */
    for (int i = -1; i < 12; i++) {
        float wx = i * 60.0f - fmodf(cx * 0.35f, 60.0f) + (((i + (int)(cx * 0.35f / 60)) * 37) % 20);
        int bx = (int)wx, k = i + (int)(cx * 0.35f / 60);
        if (w == 0) { int h = 22 + (k * 13 & 15); tri(bx, 130, bx + 14, 130, bx + 7, 130 - h, 0x1b3a34); tri(bx + 1, 130 - h / 2, bx + 13, 130 - h / 2, bx + 7, 130 - h - 6, 0x1b3a34); }
        else if (w == 1) { int h = 20 + (k * 11 & 15); tri(bx, 132, bx + 36, 132, bx + 18, 132 - h, 0x5a2a50); }
        else { int h = 34 + (k * 17 & 31); rect(bx, 134 - h, 18, h, 0x120e24); for (int j = 0; j < h / 10; j++) if (((k + j) & 1)) rect(bx + 7, 134 - h + 4 + j * 9, 3, 4, 0xffc050); }
    }
    for (int x = 0; x < SCR_W; x++) {
        float wx = x + cx * 0.45f;
        int hy = (int)(128 + sinf(wx * 0.03f + 1) * 8 + sinf(wx * 0.08f) * 3);
        for (int y = hy; y < SCR_H; y++) g_fb[y * SCR_W + x] = HILLN[w];
    }
}
static void draw_tiles(int w, int cxi) {
    int t0 = cxi / TS;
    for (int ty = 0; ty < MAP_H; ty++) for (int tx = t0; tx <= t0 + SCR_W / TS + 1; tx++) {
        int t = tile(tx, ty); if (tx < 0 || tx >= map_w || !t) continue;
        int sx = tx * TS - cxi, sy = ty * TS;
        if (t == 2) { rect(sx, sy, TS, 4, TTOP[w]); rect(sx, sy + 4, TS, 2, TDARK[w]); rect(sx, sy, TS, 1, 0xffffff - 0x606060); continue; }
        int top = tile(tx, ty - 1) != 1;
        rect(sx, sy, TS, TS, TBODY[w]);
        for (int j = 0; j < TS; j++) for (int i = 0; i < TS; i++) if (((tx * 7 + ty * 13 + i * 3 + j * 5) & 15) == 0) px(sx + i, sy + j, TDARK[w]);
        if (top) { rect(sx, sy, TS, 4, TTOP[w]); rect(sx, sy + 4, TS, 1, TDARK[w]); rect(sx, sy, TS, 1, lerpc(TTOP[w], 0xffffff, 0.35f)); }
    }
}

/* ------------------------------------------------------------ desenho de entidades */
static void draw_player(int i, int cxi) {
    Player *p = &pl[i]; if (i >= np) return;
    if (!p->alive) { /* fantasminha esperando */
        if (np == 2 && pl[1 - i].alive) { int x = RND(pl[1 - i].x) - cxi + (i ? 14 : -14), y = RND(pl[1 - i].y) - 16 + RND(sinf(frame * 0.1f) * 3); ell(x + 5, y + 5, 5, 5, 0xc8d8ff); char b[8]; num_str(b, p->respawn / 60 + 1); text(x + 3, y - 8, b, 0xffffff, 1); }
        return;
    }
    if (p->inv > 0 && (frame / 3) % 2 && p->dash <= 0) return;
    const char **spr = (p->anim / 6) % 2 && p->ground ? SPR_LUMI_B : SPR_LUMI_A;
    int x = RND(p->x) - cxi - 1, y = RND(p->y) - 1;
    draw_spr(x, y, spr, 12, 15, p->face < 0, &PALS[i], p->dash > 0);
    /* brilho da lampada */
    if (frame % 40 < 20) px(x + (p->face > 0 ? 3 : 8), y + 3, 0xffffff);
}
static void draw_enemy(Enemy *e, int cxi) {
    int x = RND(e->x) - cxi, y = RND(e->y), f = e->flash > 0;
    if (e->type == 0) {
        uint32_t c = f ? 0xffffff : 0x8a4fd6, d = f ? 0xffffff : 0x5a2fa0;
        rect(x + 2, y, 8, 1, c); rect(x + 1, y + 1, 10, 2, c); rect(x, y + 3, 12, 5, c); rect(x + 1, y + 8, 10, 2, d);
        int fo = (e->t / 8) % 2; rect(x + 1 + fo, y + 9, 3, 1, 0x1a1226); rect(x + 8 - fo, y + 9, 3, 1, 0x1a1226);
        int ex = e->dir > 0 ? 6 : 2; rect(x + ex, y + 3, 3, 3, 0xffffff); px(x + ex + (e->dir > 0 ? 2 : 0), y + 4, 0x1a1226); px(x + ex + (e->dir > 0 ? 2 : 0), y + 5, 0x1a1226);
    } else if (e->type == 1) {
        uint32_t c = f ? 0xffffff : 0xd64f6a;
        int wy = (int)(sinf(e->t * 0.4f) * 4);
        tri(x + 2, y + 4, x - 5, y + 2 + wy, x + 1, y + 8, 0x7a2a46); tri(x + 10, y + 4, x + 17, y + 2 + wy, x + 11, y + 8, 0x7a2a46);
        ell(x + 6, y + 5, 5, 4, c); rect(x + 3, y + 3, 3, 3, 0xffffff); px(x + 3, y + 4, 0x1a1226);
    } else {
        uint32_t c = f ? 0xffffff : 0x3fa07a;
        Player *p = nearest(e->x); float a = atan2f(p->y + 6 - (e->y + 4), p->x + 5 - (e->x + 7));
        rect(x + 1, y + 6, 12, 8, c); rect(x + 3, y + 4, 8, 2, c); rect(x, y + 12, 14, 2, 0x25604a);
        line(x + 7, y + 5, x + 7 + (int)(cosf(a) * 9), y + 5 + (int)(sinf(a) * 9), 0x1a1226);
        rect(x + 5, y + 8, 4, 3, 0xffffff); px(x + 7, y + 9, 0xd02040);
    }
}
static void draw_boss(int cxi) {
    Boss *b = &boss; if (!b->on) return;
    int x = RND(b->x) - cxi, y = RND(b->y), f = b->flash > 0;
    if (b->dying > 0 && (frame & 2)) return;
    Player *tp = nearest(b->x); int look = tp->x + 5 > b->x + b->w / 2 ? 1 : -1;
    if (b->type == 0) {
        uint32_t c = f ? 0xffffff : 0x5fd6b0, d = f ? 0xffffff : 0x2f9a80;
        int sq = b->state == 1 ? (int)(b->vy * 1.2f) : (int)(sinf(frame * 0.12f) * 2);
        int ry = b->h / 2 + sq / 2, rx = b->w / 2 - sq / 2;
        ell(x + b->w / 2, y + b->h - ry, rx + 1, ry + 1, 0x143a30);
        ell(x + b->w / 2, y + b->h - ry, rx, ry, c);
        ell(x + b->w / 2 - 8, y + b->h - ry - 6, 6, 4, f ? 0xffffff : 0x9ff0d8);
        rect(x + 8, y + b->h - 6, b->w - 16, 6, d);
        int ey = y + b->h - ry + 4;
        for (int k = 0; k < 2; k++) { int ex = x + b->w / 2 - 14 + k * 20; rect(ex, ey, 10, 9, 0xffffff); rect(ex + (look > 0 ? 6 : 1), ey + 3, 3, 4, 0x1a1226); line(ex, ey - 1 + (k ? 3 : 0), ex + 10, ey + 3 - (k ? 3 : 0), 0x143a30); }
        int cy = y + b->h - ry - 2; /* coroa */
        rect(x + b->w / 2 - 12, cy - 4, 24, 5, 0xffd23c);
        for (int k = 0; k < 4; k++) tri(x + b->w / 2 - 12 + k * 8, cy - 4, x + b->w / 2 - 8 + k * 8, cy - 4, x + b->w / 2 - 10 + k * 8, cy - 10, 0xffd23c);
    } else if (b->type == 1) {
        uint32_t c = f ? 0xffffff : 0x2a2440, d = f ? 0xffffff : 0x4a3f78;
        int fl = (int)(sinf(frame * 0.3f) * 10) * (b->state == 2 ? 0 : 1) - (b->state == 2 ? 8 : 0);
        tri(x + 10, y + 12, x - 14, y + 6 + fl, x - 6, y + 24, d); tri(x + 34, y + 12, x + 58, y + 6 + fl, x + 50, y + 24, d);
        tri(x + 10, y + 10, x - 4, y + 14 + fl / 2, x + 4, y + 22, c); tri(x + 34, y + 10, x + 48, y + 14 + fl / 2, x + 40, y + 22, c);
        ell(x + 22, y + 15, 17, 12, c);
        tri(x + 20, y + 14, x + 20 + look * 14, y + 17, x + 20, y + 22, 0xe89030);
        rect(x + 22 + look * 6 - 2, y + 8, 5, 5, 0xffffff); rect(x + 22 + look * 6, y + 9, 2, 3, 0xd02040);
        tri(x + 14, y + 4, x + 20, y + 4, x + 17, y - 4, c); tri(x + 22, y + 4, x + 28, y + 4, x + 25, y - 3, c);
        if (b->state == 1 && (frame / 4) % 2) rect(x, y + b->h, b->w, 1, 0xff4040);
    } else {
        uint32_t c = f ? 0xffffff : 0x7a3ad6, d = f ? 0xffffff : 0xb68aff;
        float a0 = frame * 0.02f;
        for (int k = 0; k < 8; k++) { float a = a0 + k * PI_F / 4; tri(x + 18 + (int)(cosf(a) * 14), y + 18 + (int)(sinf(a) * 14), x + 18 + (int)(cosf(a + 0.2f) * 14), y + 18 + (int)(sinf(a + 0.2f) * 14), x + 18 + (int)(cosf(a + 0.1f) * 25), y + 18 + (int)(sinf(a + 0.1f) * 25), 0xffd23c); }
        ell(x + 18, y + 18, 18, 18, 0x1a0a3a); ell(x + 18, y + 18, 16, 16, c); ell(x + 18, y + 18, 11, 11, d);
        ell(x + 18, y + 18, 7, 7, 0xffffff); rect(x + 17 + look * 2, y + 12, 3, 12, 0x1a0a3a);
    }
}
static void draw_bullets(int cxi) {
    for (int i = 0; i < MAXB; i++) if (bl[i].on) {
        int x = RND(bl[i].x) - cxi, y = RND(bl[i].y);
        if (!bl[i].enemy) { rect(x - 2, y - 1, 5, 3, 0xfff4a0); rect(x - 1, y - 2, 3, 5, 0xffd23c); px(x, y, 0xffffff); }
        else { ell(x, y, 3, 3, 0xff3060); ell(x, y, 2, 2, 0xffa0b0); px(x, y, 0xffffff); }
    }
}
static void draw_heart(int x, int y, int full) {
    static const char *H[6] = { "0110110", "1111111", "1111111", "0111110", "0011100", "0001000" };
    for (int j = 0; j < 6; j++) for (int i = 0; i < 7; i++) if (H[j][i] == '1') px(x + i, y + j, full ? 0xff3c5a : 0x4a3a50);
}

/* ------------------------------------------------------------ cena de jogo */
static void finish_result(int win) {
    state = S_RESULT; res_win = win; end_timer = 0; new_record = 0;
    audio_play(win ? TRK_WIN : TRK_LOSE, 0);
    if (win && !tut) {
        int node = cur - 1, secs = level_time / 60; if (secs < 1) secs = 1;
        if (node + 1 < NODES && sv.progress < node + 1) sv.progress = node + 1;
        if (coins_got > sv.best_coins[node]) { sv.best_coins[node] = coins_got; new_record = 1; }
        if (sv.best_time[node] == 0 || secs < sv.best_time[node]) { sv.best_time[node] = secs; new_record = 1; }
        sv.total_coins += coins_got;
        progress = sv.progress;
        save_write(&sv);
    }
}
static void update_play(void) {
    if (prs[0] & PAD_START || prs[1] & PAD_START) paused = !paused;
    if (paused) { if ((prs[0] | prs[1]) & PAD_BACK) { state = (tut ? S_TITLE : S_MAP); } return; }
    level_time++; if (intro > 0) intro--;
    for (int i = 0; i < 2; i++) update_player(i);
    /* camera */
    if (LV[cur].kind != K_BOSS) {
        float sum = 0; int n = 0;
        for (int i = 0; i < np; i++) if (pl[i].alive) { sum += pl[i].x; n++; }
        if (n) { float t = clampf(sum / n - SCR_W / 2 + 40, 0, map_w * TS - SCR_W); camx += (t - camx) * 0.1f; if (camx < 0) camx = 0; }
    }
    update_enemies(); update_boss(); update_beams(); update_bullets();
    for (int i = 0; i < MAXP; i++) if (part[i].life > 0) { part[i].life--; part[i].x += part[i].vx; part[i].y += part[i].vy; part[i].vy += 0.05f; }
    if (shake > 0) { shake--; shx = rndi(-1, 1) * (shake > 3 ? 2 : 1); shy = rndi(-1, 1); } else shx = shy = 0;
    /* vitoria / derrota */
    int alive = 0; for (int i = 0; i < np; i++) alive += pl[i].alive;
    if (LV[cur].kind != K_BOSS) {
        float gx = (map_w - 6) * TS;
        for (int i = 0; i < np; i++) if (pl[i].alive && pl[i].x > gx && end_timer == 0) end_timer = 60, res_win = 1;
    }
    if (!alive && end_timer == 0) { end_timer = 90; res_win = 0; }
    if (end_timer > 0 && --end_timer == 0) finish_result(res_win);
    if (res_win == 1 && boss.on == 0 && LV[cur].kind == K_BOSS && end_timer == 0 && state == S_PLAY) finish_result(1);
}
static void draw_play(void) {
    const LevelDef *L = &LV[cur]; int cxi = RND(camx);
    shx = shy = 0;
    draw_bg(L->world, camx);
    shx = shake > 0 ? rndi(-1, 1) : 0; shy = shake > 0 ? rndi(-1, 1) : 0;
    draw_tiles(L->world, cxi);
    if (L->kind != K_BOSS) { /* bandeira */
        int gx = (map_w - 6) * TS - cxi + 8, gy = GROUND_ROW * TS;
        rect(gx, gy - 44, 2, 44, 0xe8e8e8);
        for (int k = 0; k < 18; k++) rect(gx + 2 + k, gy - 44 + (int)(sinf(frame * 0.15f + k * 0.4f) * 2) + k / 6, 1, 12 - k / 3, 0xff4a5a);
        ell(gx + 1, gy - 46, 2, 2, 0xffd23c);
    }
    for (int i = 0; i < ncoins; i++) if (!coins[i].got) {
        int x = RND(coins[i].x) - cxi, y = RND(coins[i].y), w = (int)fabsf(sinf((frame + i * 5) * 0.12f) * 3) + 1;
        if (x > -8 && x < SCR_W + 8) { ell(x, y, w + 1, 4, 0xb8860b); ell(x, y, w, 3, 0xffd23c); }
    }
    for (int i = 0; i < MAXE; i++) if (en[i].on && en[i].act) draw_enemy(&en[i], cxi);
    draw_boss(cxi);
    for (int i = 0; i < 2; i++) if (beams[i].on) {
        int x = beams[i].x - cxi;
        if (beams[i].t < 45) { if ((frame / 3) % 2) { rect(x - 1, 0, 2, GROUND_ROW * TS, 0xffa0ff); } }
        else { rect(x - 9, 0, 18, GROUND_ROW * TS, 0xb040ff); rect(x - 5, 0, 10, GROUND_ROW * TS, 0xf0d0ff); rect(x - 2, 0, 4, GROUND_ROW * TS, 0xffffff); }
    }
    draw_bullets(cxi);
    for (int i = 1; i >= 0; i--) draw_player(i, cxi);
    for (int i = 0; i < MAXP; i++) if (part[i].life > 0) { int s = part[i].life > part[i].max / 2 ? 2 : 1; rect(RND(part[i].x) - cxi, RND(part[i].y), s, s, part[i].c); }
    shx = shy = 0;
    /* HUD */
    for (int i = 0; i < np; i++) {
        int x = i ? SCR_W - 6 - 27 : 6;
        for (int h = 0; h < 3; h++) draw_heart(x + h * 9, 6, pl[i].hp > h && pl[i].alive);
        text(i ? SCR_W - 6 - text_w(i ? "P2 PIP" : "P1 LUMI", 1) : 6, 15, i ? "P2 PIP" : "P1 LUMI", i ? 0xff9ac0 : 0xffe060, 1);
    }
    char b[16]; num_str(b, coins_got); text(SCR_W / 2 - 10, 6, "x", 0xffd23c, 1); text(SCR_W / 2 - 2, 6, b, 0xffffff, 1);
    ell(SCR_W / 2 - 14, 8, 3, 3, 0xffd23c);
    if (boss.on) {
        int bw = 200, bx = (SCR_W - bw) / 2, by = SCR_H - 9;
        rect(bx - 2, by - 2, bw + 4, 8, 0x0c0816); rect(bx, by, bw, 4, 0x4a1a2a);
        rect(bx, by, boss.hp > 0 ? bw * boss.hp / boss.maxhp : 0, 4, 0xff4a5a);
        text_c(by - 10, L->name, 0xffffff, 1);
    }
    if (tut) {
        float sum = 0; int n = 0; for (int i = 0; i < np; i++) if (pl[i].alive) { sum += pl[i].x; n++; }
        int tx = n ? (int)(sum / n) / TS : 0, k = 0;
        for (int i = 0; i < 7; i++) if (tx >= TUTP[i].x) k = i;
        int w = text_w(TUTP[k].s, 1) + 12; rect((SCR_W - w) / 2, 26, w, 14, 0x0c0816); rect((SCR_W - w) / 2, 26, w, 1, 0xffd23c); rect((SCR_W - w) / 2, 39, w, 1, 0xffd23c);
        text_c(30, TUTP[k].s, 0xffffff, 1);
    }
    if (intro > 0 && !tut) { int yy = 52 + (intro < 20 ? (20 - intro) * -3 : 0); text_c(yy, L->name, 0xffd23c, 2); text_c(yy + 14, L->sub, 0xffffff, 1); }
    if (paused) { rect(0, 60, SCR_W, 56, 0x0c0816); text_c(68, "PAUSA", 0xffd23c, 3); text_c(92, "START CONTINUA", 0xffffff, 1); text_c(102, "TRIANGULO SAIR DA FASE", 0xffffff, 1); }
    if (end_timer > 0 && res_win == 1 && boss.dying == 0) { /* flash de fim */ }
}

/* ------------------------------------------------------------ telas */
static void draw_title_chars(int y) {
    int bob = (int)(sinf(frame * 0.08f) * 2);
    draw_spr(40, y + bob, SPR_LUMI_A, 12, 15, 0, &PALS[0], 0);
    draw_spr(SCR_W - 52, y - bob, SPR_LUMI_A, 12, 15, 1, &PALS[1], 0);
}
static void update_title(void) {
    uint16_t pr = prs[0] | prs[1];
    if (pr & PAD_UP) { menusel = (menusel + 4) % 5; audio_sfx(SFX_MENU); }
    if (pr & PAD_DOWN) { menusel = (menusel + 1) % 5; audio_sfx(SFX_MENU); }
    if (pr & (PAD_JUMP | PAD_START)) {
        audio_sfx(SFX_SELECT);
        if (menusel == 0) { np = 1; state = S_MAP; mapsel = progress; }
        else if (menusel == 1) { np = 2; state = S_MAP; mapsel = progress; }
        else if (menusel == 2) { np = 1; start_level(0); }
        else if (menusel == 3) { sv.music = !sv.music; audio_set_music(sv.music); save_write(&sv); }
        else want_quit = 1;
    }
}
static void draw_title(void) {
    draw_bg(2, frame * 0.4f);
    for (int i = 0; i < 2; i++) { int bx = 50 + i * 100 + (frame / 3) % 4; (void)bx; }
    int bob = (int)(sinf(frame * 0.05f) * 3);
    text_c(22 + bob, "LUMI E PIP", 0xffd23c, 6);
    text_c(58 + bob, "AVENTURA SOMBRIA", 0xff9ac0, 2);
    draw_title_chars(46);
    const char *items[5] = { "1 JOGADOR", "2 JOGADORES", "TUTORIAL", sv.music ? "MUSICA: SIM" : "MUSICA: NAO", "SAIR" };
    for (int i = 0; i < 5; i++) {
        uint32_t c = i == menusel ? 0xffffff : 0x9a8ab8;
        if (i == menusel) text(SCR_W / 2 - text_w(items[i], 2) / 2 - 14, 80 + i * 14, ">", 0xffd23c, 2);
        text_c(80 + i * 14, items[i], c, 2);
    }
    { int done = 0; for (int i = 0; i < NODES; i++) done += sv.best_time[i] > 0;
      char b[16]; num_str(b, done); char m[40]; strcpy(m, "FASES CONCLUIDAS: "); strcat(m, b); strcat(m, "/6");
      text_c(SCR_H - 32, m, 0xffd23c, 1); }
    text_c(SCR_H - 22, "X CONFIRMA  -  QUADRADO ATIRA  -  R1 DASH", 0xc8b8e8, 1);
    text_c(SCR_H - 12, "2 JOGADORES: LIGUE O SEGUNDO CONTROLE", 0x8a7aa8, 1);
}

static const int NX[NODES] = { 40, 90, 150, 200, 250, 285 }, NY[NODES] = { 128, 88, 124, 72, 108, 44 };
static void update_map(void) {
    uint16_t pr = prs[0] | prs[1];
    if ((pr & PAD_RIGHT) && mapsel < progress && mapsel < NODES - 1) mapsel++;
    if ((pr & PAD_LEFT) && mapsel > 0) mapsel--;
    if (pr & PAD_BACK) state = S_TITLE;
    if (pr & (PAD_JUMP | PAD_START)) start_level(mapsel + 1);
}
static void draw_map(void) {
    draw_bg(0, frame * 0.3f);
    rect(0, 150, SCR_W, SCR_H - 150, 0x1c2a5a);
    for (int i = 0; i < 20; i++) rect((i * 47 + frame / 2) % SCR_W, 156 + (i * 13) % 18, 8, 1, 0x3a5aa0);
    for (int i = 0; i < NODES - 1; i++) {
        int n = 12;
        for (int k = 0; k < n; k++) if (k % 2 == 0) { int x = NX[i] + (NX[i + 1] - NX[i]) * k / n, y = NY[i] + (NY[i + 1] - NY[i]) * k / n; rect(x - 1, y - 1, 3, 3, i < progress ? 0xffd23c : 0x6a5a8a); }
    }
    for (int i = 0; i < NODES; i++) {
        int boss_ = LV[i + 1].kind == K_BOSS, lock = i > progress, done = i < progress;
        uint32_t c = lock ? 0x5a4a6a : (boss_ ? 0xd0305a : 0x3c9ae6);
        ell(NX[i], NY[i], 8, 8, 0x0c0816); ell(NX[i], NY[i], 7, 7, c);
        if (boss_) { rect(NX[i] - 3, NY[i] - 3, 7, 5, 0xffffff); rect(NX[i] - 2, NY[i] - 2, 2, 2, 0x0c0816); rect(NX[i] + 1, NY[i] - 2, 2, 2, 0x0c0816); rect(NX[i] - 2, NY[i] + 2, 5, 2, 0xffffff); }
        else { rect(NX[i] - 1, NY[i] - 4, 1, 8, 0xffffff); tri(NX[i], NY[i] - 4, NX[i] + 4, NY[i] - 2, NX[i], NY[i], 0xffd23c); }
        if (done) { ell(NX[i] + 6, NY[i] - 8, 3, 3, 0xffd23c); }
    }
    int bob = (int)(sinf(frame * 0.12f) * 2);
    draw_spr(NX[mapsel] - 6, NY[mapsel] - 24 + bob, SPR_LUMI_A, 12, 15, 0, &PALS[0], 0);
    if (np == 2) draw_spr(NX[mapsel] + 6, NY[mapsel] - 22 - bob, SPR_LUMI_A, 12, 15, 1, &PALS[1], 0);
    text_c(6, "MAPA", 0xffd23c, 2);
    rect(0, SCR_H - 30, SCR_W, 30, 0x0c0816);
    text_c(SCR_H - 26, LV[mapsel + 1].name, 0xffffff, 2);
    text_c(SCR_H - 12, LV[mapsel + 1].sub, 0xff9ac0, 1);
    text(6, SCR_H - 12, "X ENTRAR", 0xffd23c, 1);
    text(SCR_W - 6 - text_w("TRIANGULO VOLTAR", 1), SCR_H - 12, "TRIANGULO VOLTAR", 0xc8b8e8, 1);
}
static void update_result(void) {
    if ((prs[0] | prs[1]) & (PAD_JUMP | PAD_START)) {
        if (res_win) {
            if (tut) { state = S_TITLE; return; }
            int node = cur - 1; if (progress < node + 1 && node + 1 < NODES) progress = node + 1;
            if (node == NODES - 1) { state = S_TITLE; return; }
            mapsel = node + 1 < NODES ? node + 1 : node; state = S_MAP;
        } else state = tut ? S_TITLE : S_MAP;
    }
    if (!res_win && ((prs[0] | prs[1]) & PAD_SHOOT)) start_level(cur);
}
static void draw_result(void) {
    draw_play();
    rect(0, 40, SCR_W, 96, 0x0c0816); rect(0, 40, SCR_W, 1, 0xffd23c); rect(0, 135, SCR_W, 1, 0xffd23c);
    char b[16];
    if (res_win) {
        int final_ = !tut && cur - 1 == NODES - 1;
        text_c(50, final_ ? "VOCE VENCEU!" : "VITORIA!", 0xffd23c, 4);
        if (final_) text_c(80, "A LUZ VOLTOU AO REINO", 0xffffff, 1);
        text(100, 92, "MOEDAS", 0xffffff, 1); num_str(b, coins_got); text(170, 92, b, 0xffd23c, 1);
        text(100, 102, "TEMPO", 0xffffff, 1); num_str(b, level_time / 60); text(170, 102, b, 0xffd23c, 1); text(180 + 4 * (int)strlen(b), 102, "S", 0xffd23c, 1);
        if (new_record) text_c(76 + (final_ ? 10 : 0), "NOVO RECORDE!", 0xff9ac0, 1);
        text_c(120, "X CONTINUAR  (PROGRESSO SALVO)", 0xc8b8e8, 1);
    } else {
        text_c(54, "FIM DE JOGO", 0xff5a6a, 4);
        text_c(96, "QUADRADO TENTAR DE NOVO", 0xffffff, 1);
        text_c(110, "X VOLTAR", 0xc8b8e8, 1);
    }
}

/* ------------------------------------------------------------ API */
void game_init(void) {
    state = S_TITLE; menusel = 0; mapsel = 0; np = 1; frame = 0; want_quit = 0; rng_state = 99;
    save_load(&sv); progress = sv.progress; mapsel = progress;
    audio_init(); audio_set_music(sv.music);
}
int game_quit_requested(void) { return want_quit; }
void game_debug_start(int level, int players) { np = players; start_level(level); }
void game_update(uint16_t p0, uint16_t p1) {
    uint16_t in[2] = { p0, p1 };
    for (int i = 0; i < 2; i++) { held[i] = in[i]; prs[i] = in[i] & ~oldheld[i]; oldheld[i] = in[i]; }
    frame++;
    switch (state) {
        case S_TITLE: update_title(); break;
        case S_MAP: update_map(); break;
        case S_PLAY: update_play(); break;
        case S_RESULT: update_result(); break;
    }
    if (state == S_TITLE) audio_play(TRK_TITLE, 0);
    else if (state == S_MAP) audio_play(TRK_MAP, 0);
    else if (state == S_PLAY) {
        const LevelDef *L = &LV[cur];
        if (L->kind == K_BOSS) audio_play(TRK_BOSS, L->boss * 2);
        else audio_play(TRK_RUN0 + L->world, 0);
    }
    shx = shy = 0;
    switch (state) {
        case S_TITLE: draw_title(); break;
        case S_MAP: draw_map(); break;
        case S_PLAY: draw_play(); break;
        case S_RESULT: draw_result(); break;
    }
}
