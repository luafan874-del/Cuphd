/* Sintetizador chiptune: musica original (pulso + triangulo + bateria de ruido) e efeitos. */
#include "audio.h"
#include <math.h>
#include <string.h>
#include <stdint.h>

#define R 99
typedef struct { int bpm, root, drums, bars, loop, lead_oct; signed char la[16], lb[16], bass[16], roots[4]; } Track;

static const Track TR[TRK_COUNT] = {
 /* TITLE */ { 88, 57, 0, 0, 1, 12, {0,R,R,3,R,5,R,R,7,R,5,R,3,R,R,R}, {5,R,R,7,R,10,R,R,12,R,10,R,7,R,5,R}, {0,R,R,R,0,R,R,R,0,R,R,R,7,R,R,R}, {0,-4,-2,-5} },
 /* MAP   */ { 104, 60, 1, 0, 1, 12, {0,R,4,R,7,R,4,R,9,R,7,R,4,R,2,R}, {7,R,9,R,12,R,9,R,7,R,4,R,2,R,0,R}, {0,R,R,0,R,R,0,R,7,R,R,7,R,R,4,R}, {0,-3,-7,-5} },
 /* RUN0  */ { 136, 57, 2, 0, 1, 12, {0,R,3,5,R,7,R,5,3,R,5,R,7,R,10,R}, {12,R,10,7,R,10,R,7,5,R,7,R,3,R,5,3}, {0,0,R,0,0,R,0,R,0,0,R,0,0,R,7,R}, {0,0,-4,-2} },
 /* RUN1  */ { 124, 52, 2, 0, 1, 12, {0,R,1,R,4,R,5,4,R,1,R,0,R,R,1,R}, {7,R,8,R,7,R,5,4,R,5,R,4,R,1,0,R}, {0,R,0,R,1,R,0,R,0,R,0,R,5,R,4,R}, {0,0,1,0} },
 /* RUN2  */ { 146, 50, 2, 0, 1, 12, {0,R,0,R,3,R,6,R,7,R,6,R,3,R,0,R}, {10,R,7,R,6,R,7,R,10,R,12,R,10,R,7,R}, {0,0,0,R,0,0,R,0,0,0,0,R,3,3,R,5}, {0,-2,-4,-5} },
 /* BOSS  */ { 164, 45, 3, 0, 1, 24, {0,3,R,0,6,R,7,R,0,3,R,0,10,R,7,6}, {12,R,10,R,7,6,7,R,3,R,6,R,7,R,10,12}, {0,0,R,0,0,R,0,0,0,0,R,0,3,R,5,R}, {0,0,-2,1} },
 /* WIN   */ { 150, 60, 0, 2, 0, 12, {0,4,7,12,R,R,7,12,16,R,R,R,19,R,R,R}, {16,R,12,R,19,R,R,R,24,R,R,R,R,R,R,R}, {0,R,R,R,7,R,R,R,0,R,R,R,R,R,R,R}, {0,0,0,0} },
 /* LOSE  */ { 80, 57, 0, 1, 0, 12, {7,R,R,R,5,R,R,R,3,R,R,R,0,R,R,R}, {R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R}, {0,R,R,R,R,R,R,R,-2,R,R,R,R,R,R,R}, {0,0,0,0} },
};

static volatile int pend_flag, pend_track, pend_trans, music_on = 1;
static int cur = -1, trans, step, running;
static float step_pos, step_len, age_l, age_b, age_k, age_s, age_h;
static float ph_l, ph_b, f_l, f_b, kick_ph;
static uint32_t noise_s = 12345;

typedef struct { volatile int on; float f0, f1, ph, t, dur, vol; int noise; } Sfx;
static Sfx sfx[8];

static float mtof(int m) { return 440.0f * powf(2.0f, (m - 69) / 12.0f); }
static float noise(void) { noise_s ^= noise_s << 13; noise_s ^= noise_s >> 17; noise_s ^= noise_s << 5; return (noise_s & 0xFFFF) / 32768.0f - 1.0f; }

void audio_init(void) { memset(sfx, 0, sizeof sfx); cur = -1; running = 0; }
void audio_set_music(int on) { music_on = on; }
void audio_play(int track, int transpose) {
    if (pend_flag) { pend_track = track; pend_trans = transpose; return; }
    if (track == cur && transpose == trans) return;
    pend_track = track; pend_trans = transpose; pend_flag = 1;
}
void audio_sfx(int id) {
    static const struct { float f0, f1, dur, vol; int noise; } D[] = {
        { 900, 500, 0.06f, 0.06f, 0 }, { 300, 650, 0.12f, 0.08f, 0 }, { 0, 0, 0.12f, 0.07f, 1 }, { 1200, 1900, 0.10f, 0.07f, 0 },
        { 420, 90, 0.25f, 0.12f, 0 }, { 0, 0, 0.20f, 0.14f, 1 }, { 0, 0, 0.80f, 0.20f, 1 }, { 210, 150, 0.03f, 0.05f, 0 },
        { 700, 700, 0.04f, 0.06f, 0 }, { 500, 1000, 0.10f, 0.08f, 0 } };
    for (int i = 0; i < 8; i++) if (!sfx[i].on) {
        Sfx *s = &sfx[i]; s->f0 = D[id].f0; s->f1 = D[id].f1; s->dur = D[id].dur; s->vol = D[id].vol; s->noise = D[id].noise; s->t = 0; s->ph = 0; s->on = 1; return;
    }
}

static void start_track(void) {
    cur = pend_track; trans = pend_trans; pend_flag = 0;
    step = 0; step_pos = 0; running = 1; age_l = age_b = age_k = age_s = age_h = 99999;
    step_len = AUDIO_RATE * 15.0f / TR[cur].bpm;
}
static void trigger(void) {
    const Track *t = &TR[cur]; int p = step & 15, bar = step >> 4;
    if (!t->loop && bar >= t->bars) { running = 0; return; }
    const signed char *la = (bar & 1) ? t->lb : t->la;
    if (la[p] != R) { f_l = mtof(t->root + trans + t->lead_oct + la[p]); age_l = 0; }
    if (t->bass[p] != R) { f_b = mtof(t->root + trans - 12 + t->bass[p] + t->roots[bar & 3]); age_b = 0; }
    int d = t->drums;
    if (d >= 1 && (p == 0 || p == 8)) { age_k = 0; kick_ph = 0; }
    if (d >= 3 && (p == 6 || p == 14)) { age_k = 0; kick_ph = 0; }
    if (d >= 2 && (p == 4 || p == 12)) age_s = 0;
    if (d >= 2 && (p & 1) == 0) age_h = 0;
    if (d >= 3 && (p & 1)) age_h = 0;
}

void audio_mix(float *out, int frames) {
    if (pend_flag) start_track();
    const float inv = 1.0f / AUDIO_RATE;
    for (int i = 0; i < frames; i++) {
        float s = 0;
        if (music_on && running && cur >= 0) {
            if (step_pos <= 0) { trigger(); step_pos += step_len; step++; }
            step_pos -= 1.0f;
            if (running) {
                ph_l += f_l * inv; ph_l -= floorf(ph_l);
                ph_b += f_b * inv; ph_b -= floorf(ph_b);
                float el = 1.0f - age_l / (step_len * 1.6f), eb = 1.0f - age_b / (step_len * 2.2f);
                if (el < 0) el = 0;
                if (eb < 0) eb = 0;
                if (age_l < 100) el *= age_l / 100.0f < 1 ? age_l / 100.0f : 1;
                s += (ph_l < 0.25f ? 1.0f : -1.0f) * 0.09f * el;
                s += (4.0f * fabsf(ph_b - 0.5f) - 1.0f) * 0.22f * eb;
                if (age_k < AUDIO_RATE * 0.15f) { float t = age_k * inv; kick_ph += (45.0f + 90.0f * expf(-t * 35.0f)) * inv; s += sinf(kick_ph * 6.2831853f) * 0.30f * expf(-t * 18.0f); }
                if (age_s < AUDIO_RATE * 0.15f) { float t = age_s * inv; s += noise() * 0.13f * expf(-t * 28.0f); }
                if (age_h < AUDIO_RATE * 0.05f) { float t = age_h * inv; s += noise() * 0.05f * expf(-t * 90.0f); }
                age_l++; age_b++; age_k++; age_s++; age_h++;
            }
        }
        for (int v = 0; v < 8; v++) if (sfx[v].on) {
            Sfx *x = &sfx[v]; float k = x->t / x->dur, env = 1.0f - k, f = x->f0 + (x->f1 - x->f0) * k, w;
            if (x->noise) w = noise(); else { x->ph += f * inv; x->ph -= floorf(x->ph); w = x->ph < 0.5f ? 1.0f : -1.0f; }
            s += w * x->vol * env; x->t += inv;
            if (x->t >= x->dur) x->on = 0;
        }
        s *= 0.9f; if (s > 1) s = 1; if (s < -1) s = -1;
        out[2 * i] = out[2 * i + 1] = s;
    }
}
