#ifndef GAME_H
#define GAME_H
#include <stdint.h>

#define SCR_W 320
#define SCR_H 176

/* bits de entrada (a plataforma traduz DualShock/teclado para isto) */
enum {
    PAD_LEFT = 1, PAD_RIGHT = 2, PAD_UP = 4, PAD_DOWN = 8,
    PAD_JUMP = 16, PAD_SHOOT = 32, PAD_DASH = 64,
    PAD_START = 128, PAD_BACK = 256
};

extern uint32_t g_fb[SCR_W * SCR_H];   /* framebuffer 0x00RRGGBB */

void game_init(void);
void game_update(uint16_t p0, uint16_t p1);   /* 1 chamada = 1/60 s */
int  game_quit_requested(void);
void game_debug_start(int level, int players); /* so para testes */

#endif
