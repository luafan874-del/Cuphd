#include "../source/audio.h"
#include "../source/save.h"
#include <stdio.h>
#include <math.h>
#include <string.h>
int main(void){
  static float buf[2*AUDIO_RATE/4]; audio_init(); audio_set_music(1);
  const char*nm[]={"TITLE","MAP","RUN0","RUN1","RUN2","BOSS","WIN","LOSE"};
  for(int t=0;t<TRK_COUNT;t++){
    audio_play(t,0); double e=0,pk=0; long nan=0; int zc=0; float prev=0;
    for(int sec=0;sec<8;sec++){ audio_mix(buf,AUDIO_RATE/8*0+ (AUDIO_RATE/4)); for(int i=0;i<AUDIO_RATE/4;i++){float v=buf[2*i]; if(v!=v)nan++; e+=v*v; if(fabs(v)>pk)pk=fabs(v); if((v>0)!=(prev>0))zc++; prev=v;} }
    printf("%-5s rms=%.3f peak=%.2f nan=%ld zc=%d\n",nm[t],sqrt(e/(8.0*AUDIO_RATE/4)),pk,nan,zc);
  }
  audio_play(TRK_RUN0,0); audio_mix(buf,1024); audio_sfx(SFX_BIGBOOM); audio_mix(buf,4800); double e=0; for(int i=0;i<4800;i++)e+=buf[2*i]*buf[2*i]; printf("sfx rms=%.3f\n",sqrt(e/4800));
  /* wav de 12s da fase 1 para conferir */
  FILE*f=fopen("/tmp/run0.raw","wb"); audio_play(TRK_RUN0,0); for(int k=0;k<12*4;k++){audio_mix(buf,AUDIO_RATE/4); fwrite(buf,sizeof(float),2*(AUDIO_RATE/4),f);} fclose(f);
  /* save roundtrip */
  Save a,b; save_defaults(&a); a.progress=3; a.music=0; a.total_coins=42; a.best_time[1]=77; printf("write=%d ",save_write(&a));
  int ok=save_load(&b); printf("load=%d prog=%d music=%d coins=%d t1=%d\n",ok,b.progress,b.music,b.total_coins,b.best_time[1]);
  FILE*c=fopen(SAVE_PATH,"r+b"); fseek(c,12,SEEK_SET); fputc(9,c); fclose(c); ok=save_load(&b); printf("corrompido load=%d prog=%d music=%d\n",ok,b.progress,b.music);
  remove(SAVE_PATH); return 0; }
