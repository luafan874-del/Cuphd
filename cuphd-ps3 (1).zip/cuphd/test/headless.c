#include "../source/game.h"
#include <stdio.h>
#include <stdlib.h>
static void dump(const char*n){ FILE*f=fopen(n,"wb"); fprintf(f,"P6\n%d %d\n255\n",SCR_W,SCR_H);
 for(int i=0;i<SCR_W*SCR_H;i++){unsigned c=g_fb[i];fputc(c>>16,f);fputc(c>>8,f);fputc(c,f);} fclose(f);}
int main(int argc,char**argv){
 int level=argc>1?atoi(argv[1]):-1, players=argc>2?atoi(argv[2]):1, frames=argc>3?atoi(argv[3]):600;
 game_init();
 if(level<0){ for(int i=0;i<30;i++)game_update(0,0); dump("shots/title.ppm");
   game_update(PAD_JUMP,0); game_update(0,0); for(int i=0;i<20;i++)game_update(0,0); dump("shots/map.ppm"); return 0; }
 game_debug_start(level,players);
 unsigned seed=7;
 for(int f=0;f<frames;f++){
   uint16_t p=PAD_RIGHT|PAD_SHOOT; if(f%50<3)p|=PAD_JUMP; if(f%90==40)p|=PAD_DASH; if(f%120>100)p|=PAD_UP;
   if(level==2||level==4||level==6){ p=PAD_SHOOT; if((f/60)%2)p|=PAD_RIGHT; else p|=PAD_LEFT; if(f%45<3)p|=PAD_JUMP; if(f%70==30)p|=PAD_DASH; }
   game_update(p, players==2?(PAD_RIGHT|PAD_SHOOT|((f%60<3)?PAD_JUMP:0)):0);
   if(f==frames-1||f==frames/2){char n[64];sprintf(n,"shots/l%d_%d.ppm",level,f);dump(n);}
 }
 return 0; }
