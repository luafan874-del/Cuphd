# CUPHD - Lumi e Pip: Aventura Sombria (PS3 homebrew)

Jogo original em pixel art (320x176, escalado em inteiro para 720p/1080p), em C, para PS3 via PSL1GHT.
Fases corre-e-atira, 3 chefes, mapa de fases, tutorial interativo e multiplayer local para 2 (cooperativo).

## Controles
- D-pad / analogico esquerdo: mover | CIMA: mira para cima (com direcao = diagonal)
- X: pular (de novo no ar = pulo duplo; BAIXO+X desce de plataforma fina)
- QUADRADO: atirar | R1 ou O: dash (invencivel durante o dash)
- START: pausa | TRIANGULO: voltar/sair da fase
- 2 jogadores: escolha "2 JOGADORES" no menu. Se um cair, o outro segue e ele revive em 6s.

## Conteudo
Tutorial + 3 mundos (Floresta, Dunas, Castelo), cada um com uma fase corre-e-atira e um chefe:
Rei Gelatina, Mestre Corvo e Rainha Trovao. 
## Musica e save
- Musica chiptune original sintetizada em codigo (sem arquivos de audio): uma trilha para titulo, mapa, cada mundo, chefes, vitoria e derrota, alem de efeitos sonoros. Liga/desliga em "MUSICA" no menu inicial.
- Save automatico em `/dev_hdd0/game/CUPHD0001/USRDIR/cuphd.sav` ao vencer uma fase: progresso do mapa, recordes de moedas e tempo por fase, e a opcao de musica. Arquivo corrompido e ignorado (comeca do zero).
- No PC o save fica em `cuphd.sav` na pasta atual.

## Compilar o PKG
1. Instale o ps3toolchain (github.com/ps3dev/ps3toolchain) e defina PS3DEV e PSL1GHT.
2. Copie um `sfo.xml` de qualquer exemplo do PSL1GHT (pasta samples/) para esta pasta.
3. `make`  ->  gera `cuphd.pkg` (nome na XMB: CUPHD).
4. Instale o PKG em PS3 com CFW/HEN (homebrew). Nao roda em PS3 sem isso.

## Testar no PC
`make -f Makefile.pc && ./cuphd_pc` (precisa de SDL2). Setas + Z/X/C; P2: WASD + G/H/J.

## Estrutura
- source/game.c, game.h : todo o jogo (portatil, desenha em um framebuffer 320x176)
- source/main_ps3.c     : video RSX, DualShock 3, loop
- source/audio.c/.h     : sintetizador de musica e efeitos
- source/save.c/.h      : save em arquivo com checksum
- source/main_sdl.c     : versao PC para teste
- test/headless.c       : teste automatico sem janela
